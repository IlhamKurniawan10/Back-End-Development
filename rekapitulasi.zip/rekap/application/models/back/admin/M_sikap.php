<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_sikap extends CI_Model {

    

}

/* End of file M_akhlak.php */
